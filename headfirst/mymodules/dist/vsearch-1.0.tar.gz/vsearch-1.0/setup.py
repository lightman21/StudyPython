from setuptools import setup
setup(
        name = 'vsearch',
        version = '1.0',
        description = 'The ,Head First Python Search Tools',
        author = 'tanghao',
        url = 'tanghao.org',
        py_modules=['vsearch'],
        )
